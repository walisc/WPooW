``null``
========

``null`` returns ``true`` if the variable is ``null``:

.. code-block:: jinja

    {{ var is null }}

.. note::

    ``none`` is an alias for ``null``.
